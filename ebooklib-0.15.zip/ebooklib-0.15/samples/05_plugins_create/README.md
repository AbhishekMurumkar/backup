Plugins
=======

How to make your useless plugin.

## Start

    python create.py