Advanced create
===============

Create simple EPUB3 using some of advanced features of EbookLib.

## Start

    python create.py