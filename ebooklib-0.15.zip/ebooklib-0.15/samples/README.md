EbookLib Samples
================

* 01_sample_create

  Create simple EPUB with two chapters and custom CSS for the navigation.

* 02_cover_create

  Same as 01_sample_create but with cover page.

* 03_advanced_create

   Creates EPUB but uses some advanced options from the library.

* 04_markdown_parse

  Simple script which creates static markdown files + images from your EPUB.

* 05_plugins_create