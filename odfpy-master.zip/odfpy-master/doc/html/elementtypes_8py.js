var elementtypes_8py =
[
    [ "block_elements", "elementtypes_8py.html#a93bef01e769e000343dd44fd7f0c6857", null ],
    [ "declarative_elements", "elementtypes_8py.html#a0f3fdba85272e773adbe3e184125310f", null ],
    [ "empty_elements", "elementtypes_8py.html#ad5a29e22e6077343a8348bc3d1b13068", null ],
    [ "inline_elements", "elementtypes_8py.html#af6af3ee74d3bbcd994b62e093d66efce", null ]
];