var dr3d_8py =
[
    [ "Cube", "dr3d_8py.html#aba28eec6f99ef3087a9eea2466d23519", null ],
    [ "Extrude", "dr3d_8py.html#ae362ce3da2d61861bdc952e265ed2e04", null ],
    [ "Light", "dr3d_8py.html#a103936ecf1180522905dc79982c87d31", null ],
    [ "Rotate", "dr3d_8py.html#a4f9c7c75c9b3185c3528e10166ed9b2b", null ],
    [ "Scene", "dr3d_8py.html#a5a8f373f91a79140287e56efd0f2c293", null ],
    [ "Sphere", "dr3d_8py.html#a1fec5cfe7a206d33efe637fd268ce1d7", null ]
];