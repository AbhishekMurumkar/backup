var element_8py =
[
    [ "IllegalChild", "classodf_1_1element_1_1IllegalChild.html", null ],
    [ "IllegalText", "classodf_1_1element_1_1IllegalText.html", null ],
    [ "Node", "classodf_1_1element_1_1Node.html", "classodf_1_1element_1_1Node" ],
    [ "Childless", "classodf_1_1element_1_1Childless.html", "classodf_1_1element_1_1Childless" ],
    [ "Text", "classodf_1_1element_1_1Text.html", "classodf_1_1element_1_1Text" ],
    [ "CDATASection", "classodf_1_1element_1_1CDATASection.html", "classodf_1_1element_1_1CDATASection" ],
    [ "Element", "classodf_1_1element_1_1Element.html", "classodf_1_1element_1_1Element" ],
    [ "_append_child", "element_8py.html#a72f9b4d74695e54c8a2874dce970f97c", null ],
    [ "_escape", "element_8py.html#a3d7798891278df107f2b185a3e067435", null ],
    [ "_nsassign", "element_8py.html#aed683510fbe24e7cc960696088e6c6da", null ],
    [ "_nssplit", "element_8py.html#a41490bc18d7fdd968d188980bb7895a3", null ],
    [ "_quoteattr", "element_8py.html#ac8b60eb1903052af796afa1d58979e26", null ],
    [ "unicode", "element_8py.html#a9474456bb442e238b32a7bdf6a22dcba", null ]
];