var searchData=
[
  ['illegalchild',['IllegalChild',['../classodf_1_1element_1_1IllegalChild.html',1,'odf::element']]],
  ['illegaltext',['IllegalText',['../classodf_1_1element_1_1IllegalText.html',1,'odf::element']]]
];
