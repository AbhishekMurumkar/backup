var searchData=
[
  ['element',['Element',['../classodf_1_1element_1_1Element.html',1,'odf::element']]],
  ['exception',['Exception',['../classException.html',1,'']]]
];
