var searchData=
[
  ['qname',['qname',['../classodf_1_1element_1_1Element.html#af094fd4f65c213f17b319c152f8be830',1,'odf::element::Element']]],
  ['quarter',['Quarter',['../namespaceodf_1_1number.html#ae824690a033450862c823cf1c8312351',1,'odf::number']]]
];
