var searchData=
[
  ['_5f_5fdoc_5f_5f',['__doc__',['../namespaceodf_1_1grammar.html#acef64e7e05d460461ee25112dae95882',1,'odf.grammar.__doc__()'],['../namespaceodf_1_1opendocument.html#aef5700f9b878becf7cd993c97584dfee',1,'odf.opendocument.__doc__()']]],
  ['_5f_5fversion_5f_5f',['__version__',['../namespaceodf_1_1opendocument.html#a7ae7b9f7ff753deece3ec6f05a9104ee',1,'odf::opendocument']]],
  ['_5fmax_5flist_5flevel',['_MAX_LIST_LEVEL',['../namespaceodf_1_1easyliststyle.html#a3f16b7214e4de8fda12f391a12ca1ae3',1,'odf::easyliststyle']]],
  ['_5fxmlprologue',['_XMLPROLOGUE',['../namespaceodf_1_1opendocument.html#a2598e2e2f5849be1876f9a585f8359dd',1,'odf::opendocument']]]
];
