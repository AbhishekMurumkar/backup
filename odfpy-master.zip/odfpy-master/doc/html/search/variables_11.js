var searchData=
[
  ['rdfans',['RDFANS',['../namespaceodf_1_1namespaces.html#a2277c99072ff3a05a0f867164ac05690',1,'odf::namespaces']]],
  ['required_5fattributes',['required_attributes',['../namespaceodf_1_1grammar.html#a5a5da9502e3a9a572fe272da463f1877',1,'odf::grammar']]],
  ['result',['result',['../namespaceodf_1_1odfmanifest.html#a1641ce31eefa41ae260f4bd5785b37b3',1,'odf::odfmanifest']]],
  ['rptns',['RPTNS',['../namespaceodf_1_1namespaces.html#aa19decc412dfa49234ae87fb4222613b',1,'odf::namespaces']]],
  ['ruleconversions',['ruleconversions',['../classodf_1_1odf2xhtml_1_1StyleToCSS.html#a99d05d82ffecc1e04e1c9363db5ac14f',1,'odf::odf2xhtml::StyleToCSS']]]
];
