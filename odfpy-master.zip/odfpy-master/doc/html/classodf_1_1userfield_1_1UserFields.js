var classodf_1_1userfield_1_1UserFields =
[
    [ "__init__", "classodf_1_1userfield_1_1UserFields.html#a5181a6106854423e1e28a83455aa9e94", null ],
    [ "get", "classodf_1_1userfield_1_1UserFields.html#a916cc9d873f57f30b69e752bb48d5bff", null ],
    [ "get_type_and_value", "classodf_1_1userfield_1_1UserFields.html#a532884dffd16a0a946aa961ea442d3ca", null ],
    [ "list_fields", "classodf_1_1userfield_1_1UserFields.html#a9151edeae09fcea4b334a445d7efc6b0", null ],
    [ "list_fields_and_values", "classodf_1_1userfield_1_1UserFields.html#ae67ac78a3c883117d523f245f076b227", null ],
    [ "list_values", "classodf_1_1userfield_1_1UserFields.html#a1ca142bc38126c2d15a9a40e94c9d21c", null ],
    [ "loaddoc", "classodf_1_1userfield_1_1UserFields.html#a65ccd99e2c198f06b55551d6a7bbf59a", null ],
    [ "savedoc", "classodf_1_1userfield_1_1UserFields.html#ae5336dcb2cdaee62f02d16cdb8945a2f", null ],
    [ "update", "classodf_1_1userfield_1_1UserFields.html#aa13e8293efd5d183ac771d07b56a4558", null ],
    [ "dest_file", "classodf_1_1userfield_1_1UserFields.html#a4ff1ceee3cb418e2b72d6c0366fb63b3", null ],
    [ "document", "classodf_1_1userfield_1_1UserFields.html#adfbbf12e8d9c5377410d463070b5bd76", null ],
    [ "src_file", "classodf_1_1userfield_1_1UserFields.html#aab129a38d3cc36d3ca8469de9a04c5a9", null ]
];