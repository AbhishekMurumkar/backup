var namespaceodf_1_1element =
[
    [ "CDATASection", "classodf_1_1element_1_1CDATASection.html", "classodf_1_1element_1_1CDATASection" ],
    [ "Childless", "classodf_1_1element_1_1Childless.html", "classodf_1_1element_1_1Childless" ],
    [ "Element", "classodf_1_1element_1_1Element.html", "classodf_1_1element_1_1Element" ],
    [ "IllegalChild", "classodf_1_1element_1_1IllegalChild.html", null ],
    [ "IllegalText", "classodf_1_1element_1_1IllegalText.html", null ],
    [ "Node", "classodf_1_1element_1_1Node.html", "classodf_1_1element_1_1Node" ],
    [ "Text", "classodf_1_1element_1_1Text.html", "classodf_1_1element_1_1Text" ]
];