var namespaces =
[
    [ "odf", "namespaceodf.html", "namespaceodf" ]
];