var classodf_1_1element_1_1Text =
[
    [ "__init__", "classodf_1_1element_1_1Text.html#a022dd0dc36f3ad61dfa1a497a15e7778", null ],
    [ "__str__", "classodf_1_1element_1_1Text.html#ad8981ca5661cb6ddf5b3ec460d429850", null ],
    [ "__unicode__", "classodf_1_1element_1_1Text.html#add3e46b75b09f55d21ad8a9c129fb7be", null ],
    [ "toXml", "classodf_1_1element_1_1Text.html#a1b2240e8016e3833dd0651ea6d1fefb0", null ],
    [ "data", "classodf_1_1element_1_1Text.html#a57af5961fab81e5e55bbe727bff33d3e", null ],
    [ "nodeType", "classodf_1_1element_1_1Text.html#ac1eb83101645ca0be4db49cf7bd20df3", null ],
    [ "tagName", "classodf_1_1element_1_1Text.html#a4c8fd912194c2e0e9774c6df1d974e97", null ]
];