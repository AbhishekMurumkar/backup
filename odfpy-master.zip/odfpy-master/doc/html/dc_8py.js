var dc_8py =
[
    [ "Creator", "dc_8py.html#a8c6ab2e4cfa82dc1455e4285b763ab43", null ],
    [ "Date", "dc_8py.html#a92244f4e9f911af4bcb26dd9317b4b82", null ],
    [ "Description", "dc_8py.html#ace1ad37cf5dad2aa6fb7d8df33f1fc70", null ],
    [ "Language", "dc_8py.html#adb75b36f457b24405cf64f4b5f8755d5", null ],
    [ "Subject", "dc_8py.html#a6ff35f13d414fa725f600d6333e60007", null ],
    [ "Title", "dc_8py.html#a284e88c3e5bfcfb2f53eef4859829059", null ]
];